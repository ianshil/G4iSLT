# A new calculus for intuitionistic Strong Löb logic: strong termination and cut elimination, formalised

We provide a new calculus that enjoys syntactic cut elimination and strongly terminating backward proof search for the intuitionistic Strong Löb logic iSL, an intuitionistic modal logic with a provability interpretation. A novel measure on sequents is used to prove both the termination of the naive backward proof-search strategy, and the admissibility of cut in a syntactic and direct way, leading to a straightforward cut elimination procedure. All proofs have been formalised in the interactive theorem prover Coq.

## Build instructions
In a shell, do `make all`.

Tested with Coq v8.16.1.
